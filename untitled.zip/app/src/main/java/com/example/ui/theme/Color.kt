package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Custom Grocery Organic Green & Warm Sand Color Palette
val PrimaryGreen = Color(0xFF0A5C36)          // Deep Emerald Moss
val OnPrimaryColor = Color(0xFFFFFFFF)
val PrimaryContainerGreen = Color(0xFFE8F5E9)  // Soft Mint Meadow
val OnPrimaryContainerGreen = Color(0xFF003300)

val SecondaryTeal = Color(0xFF00796B)          // Accent Teal
val SecondaryContainer = Color(0xFFE0F2F1)

val AccentGold = Color(0xFFE65100)            // High contrast call-to-actions (matching JazzCash orange)
val EasypaisaGreen = Color(0xFF12CC12)         // Easypaisa Brand Green
val JazzCashOrange = Color(0xFFFF9800)         // JazzCash Brand Orange
val BankBlue = Color(0xFF0D47A1)               // General Bank Blue

val BackgroundSoftIvory = Color(0xFFF8F9F6)   // Gentle Warm Sand/Cream for organic ambiance
val SurfaceWhite = Color(0xFFFFFFFF)
val ErrorRed = Color(0xFFC62828)
val SuccessGreen = Color(0xFF2E7D32)
val TextDark = Color(0xFF1A261F)              // Sophisticated Off-black
val TextMuted = Color(0xFF63736A)             // Subtle grey-green border/text

// Dark Mode Fallbacks
val PrimaryDark = Color(0xFF81C784)
val OnPrimaryDark = Color(0xFF053316)
val PrimaryContainerDark = Color(0xFF1B5E20)
val BackgroundDark = Color(0xFF111613)
val SurfaceDark = Color(0xFF1C221E)
val TextLight = Color(0xFFE8F5E9)
val TextLightMuted = Color(0xFFA5B8AD)
