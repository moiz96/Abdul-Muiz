package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionLog
import com.example.ui.theme.*
import com.example.ui.viewmodel.GroceryViewModel
import com.example.ui.viewmodel.PaymentUiState
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(
    viewModel: GroceryViewModel,
    modifier: Modifier = Modifier
) {
    val cartList by viewModel.cartItems.collectAsState()
    val paymentMethod by viewModel.selectedPaymentMethod.collectAsState()
    val paymentState by viewModel.paymentState.collectAsState()

    // Values definition
    val subtotal = cartList.sumOf { it.totalPrice }
    val discount = if (subtotal > 1500.0) subtotal * 0.05 else 0.0
    val gstTax = subtotal * 0.02
    val grandTotal = subtotal - discount + gstTax

    // Input States
    var mobileNo by remember { mutableStateOf("") }
    var selectedBank by remember { mutableStateOf("Meezan Bank") }
    var ibanCode by remember { mutableStateOf("") }
    
    val banks = listOf("Meezan Bank", "Habib Bank Limited (HBL)", "Allied Bank (ABL)", "Mcb Bank", "Bank Alfalah", "Faysal Bank")
    var expandedBankDrop by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        when (val state = paymentState) {
            is PaymentUiState.Idle -> {
                Text(
                    text = "Select Grocery Payment Gateway",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextDark,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Gateway Selector (Easypaisa / JazzCash / Bank)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)
                ) {
                    val methods = listOf(
                        Triple("Easypaisa", EasypaisaGreen, Icons.Default.AccountBalanceWallet),
                        Triple("JazzCash", JazzCashOrange, Icons.Default.Wallet),
                        Triple("Bank Transfer", BankBlue, Icons.Default.AccountBalance)
                    )

                    methods.forEach { (name, color, icon) ->
                        val isSelected = paymentMethod == name
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp),
                            modifier = Modifier
                                .weight(1f)
                                .selectable(
                                    selected = isSelected,
                                    onClick = { viewModel.setPaymentMethod(name) }
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) color else TextMuted.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .testTag("pay_selector_$name")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = name,
                                    tint = if (isSelected) color else TextMuted,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (isSelected) color else TextDark,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // Billing info segment
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryContainerGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(16.dp).fillMaxWidth()
                    ) {
                        Column {
                            Text("Total Payable Amount", fontSize = 12.sp, color = PrimaryGreen, fontWeight = FontWeight.SemiBold)
                            Text("Basket: ${cartList.sumOf { it.quantity }} items", fontSize = 11.sp, color = TextMuted)
                        }
                        Text("Rs. ${grandTotal.toInt()}", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = AccentGold)
                    }
                }

                // Details Inputs Card depending on selection
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("payment_inputs_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Fill Secure Payment Credentials",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextDark,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        if (paymentMethod == "Easypaisa" || paymentMethod == "JazzCash") {
                            // Mobile Account Inputs
                            Text(
                                text = "Enter registered $paymentMethod mobile number",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            OutlinedTextField(
                                value = mobileNo,
                                onValueChange = { if (it.length <= 11) mobileNo = it },
                                placeholder = { Text("e.g. 03001234567") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = if (paymentMethod == "Easypaisa") EasypaisaGreen else JazzCashOrange
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("mobile_account_input")
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Note: A push verification prompt will be received on your mobile screen automatically. Open your $paymentMethod App and enter your 5-digit PIN to authenticate this payment.",
                                fontSize = 11.sp,
                                color = TextMuted,
                                lineHeight = 16.sp
                            )
                        } else {
                            // Bank Transfer Custom Dropdown & IBAN Inputs
                            Text(
                                text = "Choose Bank Name",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            
                            ExposedDropdownMenuBox(
                                expanded = expandedBankDrop,
                                onExpandedChange = { expandedBankDrop = !expandedBankDrop },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = selectedBank,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBankDrop) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = BankBlue
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor()
                                        .testTag("bank_dropdown_anchor")
                                )
                                ExposedDropdownMenu(
                                    expanded = expandedBankDrop,
                                    onDismissRequest = { expandedBankDrop = false }
                                ) {
                                    banks.forEach { bank ->
                                        DropdownMenuItem(
                                            text = { Text(bank) },
                                            onClick = {
                                                selectedBank = bank
                                                expandedBankDrop = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Enter Bank IBAN or Account Number",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            OutlinedTextField(
                                value = ibanCode,
                                onValueChange = { ibanCode = it },
                                placeholder = { Text("PK00MEZN00123456789...") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BankBlue
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("iban_account_input")
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // Pay Button
                        Button(
                            onClick = {
                                val acc = if (paymentMethod == "Bank Transfer") ibanCode else mobileNo
                                viewModel.processPayment(
                                    accountNumber = acc,
                                    subtotal = subtotal,
                                    discount = discount,
                                    tax = gstTax,
                                    grandTotal = grandTotal,
                                    bankName = selectedBank
                                )
                            },
                            enabled = cartList.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when (paymentMethod) {
                                    "Easypaisa" -> EasypaisaGreen
                                    "JazzCash" -> JazzCashOrange
                                    else -> BankBlue
                                },
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("secure_pay_trigger")
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Secure Pay Rs. ${grandTotal.toInt()}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            is PaymentUiState.Processing -> {
                // High-fidelity payment checkout progress
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = when (paymentMethod) {
                                "Easypaisa" -> EasypaisaGreen
                                "JazzCash" -> JazzCashOrange
                                else -> BankBlue
                            },
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Securing Authorization...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when (paymentMethod) {
                                "Easypaisa" -> "Awaiting direct confirm push prompt on your Easypaisa Mobile application..."
                                "JazzCash" -> "Triggering online JazzCash instant OTP clearance transaction..."
                                else -> "Connecting with Meezan Central Bank servers securely..."
                            },
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                }
            }

            is PaymentUiState.Success -> {
                // Success Invoice clearance
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = SuccessGreen,
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Payment Authorized Successfully!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextDark,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Cleared via $paymentMethod link under code:",
                            fontSize = 13.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            text = state.transaction.refNumber,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 16.sp,
                            color = AccentGold,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Success Details Details
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Paid Amount", fontSize = 12.sp, color = TextMuted)
                                    Text("Rs. ${state.transaction.grandTotal.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Status", fontSize = 12.sp, color = TextMuted)
                                    Text("Paid", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(32.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { 
                                    viewModel.resetPayment()
                                    viewModel.navigateTo(Screen.SCANNER) 
                                },
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryGreen),
                                border = BorderStroke(1.dp, PrimaryGreen),
                                modifier = Modifier.weight(1f).testTag("payment_scan_more")
                            ) {
                                Text("Scan More")
                            }

                            Button(
                                onClick = {
                                    viewModel.resetPayment()
                                    viewModel.navigateTo(Screen.HISTORY)
                                },
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                modifier = Modifier.weight(1.5f).testTag("payment_nav_receipt")
                            ) {
                                Text("View Printable Receipt")
                            }
                        }
                    }
                }
            }

            is PaymentUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Error",
                            tint = ErrorRed,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Transaction Failed",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextDark
                        )
                        Text(
                            text = state.message,
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                        )
                        Button(
                            onClick = { viewModel.resetPayment() },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.testTag("payment_error_retry")
                        ) {
                            Text("Retry Secure Checkout")
                        }
                    }
                }
            }
        }
    }
}
