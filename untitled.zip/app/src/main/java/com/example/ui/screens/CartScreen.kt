package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CartItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.GroceryViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    viewModel: GroceryViewModel,
    modifier: Modifier = Modifier
) {
    val cartList by viewModel.cartItems.collectAsState()

    // Recalculate billing values reactively
    val subtotal = cartList.sumOf { it.totalPrice }
    val discount = if (subtotal > 1500.0) subtotal * 0.05 else 0.0 // 5% discount for bulk shopping (above 1500 PKR)
    val gstTax = subtotal * 0.02 // 2% GST
    val grandTotal = subtotal - discount + gstTax

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (cartList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Empty Basket",
                        tint = TextMuted.copy(alpha = 0.4f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Your Cart is Empty",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextDark
                    )
                    Text(
                        text = "Scan QR codes of grocery items using the 'Scan QR' scanner to load products directly here.",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = TextMuted,
                        modifier = Modifier
                            .padding(top = 4.dp, start = 16.dp, end = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.navigateTo(Screen.SCANNER) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.testTag("start_scanning_trigger")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Start Scanning QR", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Header showing how many items are in cart
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Basket Items (${cartList.sumOf { it.quantity }})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextDark
                )
                TextButton(
                    onClick = { viewModel.clearCart() },
                    colors = ButtonDefaults.textButtonColors(contentColor = ErrorRed),
                    modifier = Modifier.testTag("clear_cart_btn")
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear All", fontWeight = FontWeight.SemiBold)
                }
            }

            // Cart Items Scroll
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("cart_items_list")
            ) {
                items(cartList, key = { it.barcode }) { item ->
                    CartItemRow(
                        item = item,
                        onIncrease = { viewModel.increaseCart(item.barcode) },
                        onDecrease = { viewModel.decreaseCart(item.barcode) },
                        onRemove = { viewModel.removeCartItem(item.barcode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cart Invoice Billing Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cart_summary_card")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Subtotal Row
                    BillingRow(label = "Subtotal", value = "Rs. ${subtotal.toInt()}")

                    // Bulk Discount Promo hint & Row
                    if (discount > 0) {
                        BillingRow(
                            label = "Bulk Loyalty Discount (5% Off)",
                            value = "-Rs. ${discount.toInt()}",
                            valueColor = SuccessGreen
                        )
                    }

                    // Local GST Tax Row
                    BillingRow(label = "Local GST Sales Tax (2%)", value = "Rs. ${gstTax.toInt()}")

                    Divider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = TextMuted.copy(alpha = 0.2f)
                    )

                    // Grand Total
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Grand Total",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextDark
                        )
                        Text(
                            text = "Rs. ${grandTotal.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = AccentGold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Checkout trigger button
                    Button(
                        onClick = { viewModel.navigateTo(Screen.PAYMENT_GATEWAY) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("proceed_checkout_btn")
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Proceed to Online Payments",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cart_row_${item.barcode}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(10.dp)
        ) {
            // Left category visual tag
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PrimaryContainerGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalMall,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Name + Pack specs column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.urduName,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    color = PrimaryGreen
                )
                Text(
                    text = "Rs. ${item.price.toInt()} / ${item.unit}",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            // Total price & multiplier controls layout
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "Rs. ${item.totalPrice.toInt()}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = AccentGold
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Quantity controllers
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.background(
                        color = BackgroundSoftIvory,
                        shape = RoundedCornerShape(16.dp)
                    ).padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = onDecrease,
                        modifier = Modifier.size(24.dp).testTag("decrease_qty_${item.barcode}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Reduce",
                            tint = TextDark,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Text(
                        text = item.quantity.toString(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextDark,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = onIncrease,
                        modifier = Modifier.size(24.dp).testTag("increase_qty_${item.barcode}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Increase",
                            tint = TextDark,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BillingRow(
    label: String,
    value: String,
    valueColor: Color = TextDark
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(text = label, fontSize = 13.sp, color = TextMuted)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}
