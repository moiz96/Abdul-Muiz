package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Screen {
    SCANNER,
    CATALOG,
    CART,
    PAYMENT_GATEWAY,
    HISTORY
}

sealed interface ScanUiState {
    object Idle : ScanUiState
    data class Success(val product: Product) : ScanUiState
    data class Error(val message: String) : ScanUiState
}

sealed interface PaymentUiState {
    object Idle : PaymentUiState
    object Processing : PaymentUiState
    data class Success(val transaction: TransactionLog) : PaymentUiState
    data class Error(val message: String) : PaymentUiState
}

class GroceryViewModel(private val repository: GroceryRepository) : ViewModel() {

    // Prepopulate some default products on scope initialization
    init {
        viewModelScope.launch {
            repository.prepopulateProductsIfNeeded()
        }
    }

    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionLog>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state flows
    private val _currentScreen = MutableStateFlow(Screen.SCANNER)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _scanState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val scanState: StateFlow<ScanUiState> = _scanState.asStateFlow()

    private val _paymentState = MutableStateFlow<PaymentUiState>(PaymentUiState.Idle)
    val paymentState: StateFlow<PaymentUiState> = _paymentState.asStateFlow()

    // Active Checkout Variables
    private val _selectedPaymentMethod = MutableStateFlow("Easypaisa") // "Easypaisa", "JazzCash", "Bank Transfer"
    val selectedPaymentMethod: StateFlow<String> = _selectedPaymentMethod.asStateFlow()

    // UI Navigation triggers
    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
        if (screen != Screen.PAYMENT_GATEWAY) {
            _paymentState.value = PaymentUiState.Idle
        }
    }

    fun setPaymentMethod(method: String) {
        _selectedPaymentMethod.value = method
    }

    // Interactive Barcode Scan Handler
    fun scanBarcode(barcode: String) {
        viewModelScope.launch {
            val trimmed = barcode.trim().uppercase()
            val product = repository.addBarcodeToCart(trimmed)
            if (product != null) {
                _scanState.value = ScanUiState.Success(product)
            } else {
                _scanState.value = ScanUiState.Error("Product code '$trimmed' is not registered!")
            }
        }
    }

    fun clearScanState() {
        _scanState.value = ScanUiState.Idle
    }

    // Direct actions on Catalog
    fun addProductToCart(product: Product) {
        viewModelScope.launch {
            repository.addProductToCart(product)
        }
    }

    // Cart actions
    fun increaseCart(barcode: String) {
        viewModelScope.launch {
            repository.increaseCartQuantity(barcode)
        }
    }

    fun decreaseCart(barcode: String) {
        viewModelScope.launch {
            repository.decreaseCartQuantity(barcode)
        }
    }

    fun removeCartItem(barcode: String) {
        viewModelScope.launch {
            repository.removeCartItem(barcode)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    // Payment Logic Simulation
    fun processPayment(
        accountNumber: String,
        subtotal: Double,
        discount: Double,
        tax: Double,
        grandTotal: Double,
        bankName: String = ""
    ) {
        if (accountNumber.trim().length < 10) {
            _paymentState.value = PaymentUiState.Error("Please enter a valid mobile or account number!")
            return
        }

        viewModelScope.launch {
            _paymentState.value = PaymentUiState.Processing
            
            // Simulating real payment processing delay
            delay(2500)

            // Dynamic short transaction reference code generator
            val methodPrefix = when (_selectedPaymentMethod.value) {
                "Easypaisa" -> "EP"
                "JazzCash" -> "JC"
                else -> if (bankName.length >= 2) bankName.substring(0, 2).uppercase() else "BO"
            }
            val randNum = Random.nextInt(100000, 999999)
            val generatedRef = "TXN-$methodPrefix-$randNum"

            val totalQty = cartItems.value.sumOf { it.quantity }

            val log = TransactionLog(
                refNumber = generatedRef,
                totalItems = totalQty,
                subtotal = subtotal,
                discount = discount,
                tax = tax,
                grandTotal = grandTotal,
                paymentMethod = if (_selectedPaymentMethod.value == "Bank Transfer") "Bank ($bankName)" else _selectedPaymentMethod.value,
                accountMobile = accountNumber,
                status = "Paid"
            )

            repository.saveTransaction(log)
            repository.clearCart()
            _paymentState.value = PaymentUiState.Success(log)
        }
    }

    fun resetPayment() {
        _paymentState.value = PaymentUiState.Idle
    }
}
