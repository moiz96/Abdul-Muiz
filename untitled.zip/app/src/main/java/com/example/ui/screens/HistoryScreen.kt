package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionLog
import com.example.ui.theme.*
import com.example.ui.viewmodel.GroceryViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: GroceryViewModel,
    modifier: Modifier = Modifier
) {
    val txLogs by viewModel.allTransactions.collectAsState()
    var searchLogQuery by remember { mutableStateOf("") }

    val filteredLogs = txLogs.filter {
        it.refNumber.contains(searchLogQuery, ignoreCase = true) ||
        it.paymentMethod.contains(searchLogQuery, ignoreCase = true) ||
        it.accountMobile.contains(searchLogQuery)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Log search field
        OutlinedTextField(
            value = searchLogQuery,
            onValueChange = { searchLogQuery = it },
            placeholder = { Text("Search by TRX Code, Mobile or Gateway...", color = TextMuted) },
            prefix = { Icon(Icons.Default.ManageSearch, contentDescription = null, modifier = Modifier.padding(end = 4.dp)) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryGreen,
                unfocusedBorderColor = TextMuted.copy(alpha = 0.3f),
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .testTag("history_search_input")
        )

        if (filteredLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = "No receipts",
                        tint = TextMuted.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Receipts Found",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextDark
                    )
                    Text(
                        text = "Once you check out via Easypaisa or JazzCash, your printable store logs will appear here.",
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(top = 4.dp, start = 8.dp, end = 8.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("history_logs_list")
            ) {
                items(filteredLogs, key = { it.id }) { log ->
                    ReceiptCard(log = log)
                }
            }
        }
    }
}

@Composable
fun ReceiptCard(log: TransactionLog) {
    var isExpanded by remember { mutableStateOf(false) }
    
    val sdf = SimpleDateFormat("dd MMM, yyyy - hh:mm a", Locale.getDefault())
    val formattedDate = sdf.format(Date(log.timestamp))

    // Match payment indicators beautifully
    val (brandColor, brandAccent, brandIcon) = when {
        log.paymentMethod.contains("Easypaisa", ignoreCase = true) -> 
            Triple(EasypaisaGreen, Color(0xFFE8F5E9), Icons.Default.AccountBalanceWallet)
        log.paymentMethod.contains("JazzCash", ignoreCase = true) -> 
            Triple(JazzCashOrange, Color(0xFFFFF3E0), Icons.Default.Wallet)
        else -> 
            Triple(BankBlue, Color(0xFFE3F2FD), Icons.Default.AccountBalance)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
            .testTag("receipt_card_${log.refNumber}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // Receipt Header Summary Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gateway indicator circular avatar
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(brandAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = brandIcon,
                            contentDescription = log.paymentMethod,
                            tint = brandColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = log.refNumber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextDark,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = formattedDate,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Rs. ${log.grandTotal.toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = AccentGold
                    )
                    Text(
                        text = "${log.totalItems} Items",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PrimaryGreen
                    )
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                ) {
                    Divider(color = TextMuted.copy(alpha = 0.15f), modifier = Modifier.padding(bottom = 12.dp))

                    Text(
                        text = log.storeName.uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        color = TextMuted,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "SELF-SERVICE CHECKOUT INVOICE",
                        fontWeight = FontWeight.Medium,
                        fontSize = 10.sp,
                        color = TextMuted,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Invoice breakdown
                    ReceiptDetailRow(label = "Purchase Date", value = formattedDate)
                    ReceiptDetailRow(label = "Payment Gateway", value = log.paymentMethod)
                    ReceiptDetailRow(label = "Mobile/Account Number", value = log.accountMobile)
                    ReceiptDetailRow(label = "Subtotal", value = "Rs. ${log.subtotal.toInt()}")
                    ReceiptDetailRow(label = "Loyalty Discount Saved", value = "Rs. ${log.discount.toInt()}", valueColor = SuccessGreen)
                    ReceiptDetailRow(label = "GST Output Tax", value = "Rs. ${log.tax.toInt()}")

                    Divider(color = TextMuted.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "TOTAL AMOUNT PAID",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextDark
                        )
                        Text(
                            text = "Rs. ${log.grandTotal.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = AccentGold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Transaction Status Label Badge
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SuccessGreen.copy(alpha = 0.12f))
                            .padding(vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Paid",
                            tint = SuccessGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Verified Successful via ${log.paymentMethod}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = SuccessGreen
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptDetailRow(
    label: String,
    value: String,
    valueColor: Color = TextDark
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(text = label, fontSize = 12.sp, color = TextMuted)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = valueColor)
    }
}
