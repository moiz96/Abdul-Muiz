package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDatabase
import com.example.data.GroceryRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PrimaryContainerGreen
import com.example.ui.theme.PrimaryGreen
import com.example.ui.viewmodel.GroceryViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup Edge to edge
        enableEdgeToEdge()

        // Room Database + Repository manual DI initialization
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = GroceryRepository(database.groceryDao())

        // Pass repository securely to the ViewModel using custom Provider Factory
        val viewModel = ViewModelProvider(this, object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(GroceryViewModel::class.java)) {
                    return GroceryViewModel(repository) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class context")
            }
        })[GroceryViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainAppShell(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppShell(viewModel: GroceryViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val cartList by viewModel.cartItems.collectAsState()
    val totalCartCount = cartList.sumOf { it.quantity }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Al-Madina General Store",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = PrimaryGreen
                        )
                        Text(
                            text = "المدینہ جنرل سٹور اور سیلف سروس",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                },
                navigationIcon = {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(PrimaryGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = "Store icon",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                actions = {
                    // Small local currency descriptor badge
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(PrimaryContainerGreen)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "PKR (Rs.)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreen
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("app_bottom_nav_bar")
            ) {
                // Bottom tab specifications
                val tabs = listOf(
                    NavigationTabItem(
                        screen = Screen.SCANNER,
                        label = "Scan QR",
                        selectedIcon = Icons.Default.QrCodeScanner,
                        unselectedIcon = Icons.Outlined.QrCodeScanner,
                        badgeCount = 0
                    ),
                    NavigationTabItem(
                        screen = Screen.CATALOG,
                        label = "Catalog",
                        selectedIcon = Icons.Default.MenuBook,
                        unselectedIcon = Icons.Outlined.MenuBook,
                        badgeCount = 0
                    ),
                    NavigationTabItem(
                        screen = Screen.CART,
                        label = "Basket",
                        selectedIcon = Icons.Default.ShoppingCart,
                        unselectedIcon = Icons.Outlined.ShoppingCart,
                        badgeCount = totalCartCount
                    ),
                    NavigationTabItem(
                        screen = Screen.HISTORY,
                        label = "Receipts",
                        selectedIcon = Icons.Default.ReceiptLong,
                        unselectedIcon = Icons.Outlined.ReceiptLong,
                        badgeCount = 0
                    )
                )

                tabs.forEach { tab ->
                    val isSelected = currentScreen == tab.screen || 
                        (tab.screen == Screen.CART && currentScreen == Screen.PAYMENT_GATEWAY)

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(tab.screen) },
                        icon = {
                            if (tab.badgeCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.error,
                                            contentColor = Color.White
                                        ) {
                                            Text(tab.badgeCount.toString(), fontSize = 11.sp)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryGreen,
                            selectedTextColor = PrimaryGreen,
                            indicatorColor = PrimaryContainerGreen
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.screen.name.lowercase()}")
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        
        // Active Screen router switching container (Fully safe, type-safe, reactive state machine)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.SCANNER -> ScannerScreen(viewModel = viewModel)
                Screen.CATALOG -> CatalogScreen(viewModel = viewModel)
                Screen.CART -> CartScreen(viewModel = viewModel)
                Screen.PAYMENT_GATEWAY -> PaymentScreen(viewModel = viewModel)
                Screen.HISTORY -> HistoryScreen(viewModel = viewModel)
            }
        }
    }
}

// Support class holding metadata for navigation bottom-tabs
data class NavigationTabItem(
    val screen: Screen,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int
)

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
