package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val barcode: String, // Matches scanned QR or barcode string, e.g. "PROD-MILK"
    val name: String,               // e.g. "Olper's Milk"
    val urduName: String,           // e.g. "اولپرز دودھ"
    val price: Double,              // e.g. 290.00
    val category: String,           // e.g. "Dairy"
    val unit: String,               // e.g. "1 Litre"
    val stockLevel: Int             // e.g. 45
)
