package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey val barcode: String,
    val name: String,
    val urduName: String,
    val price: Double,
    val unit: String,
    val quantity: Int
) {
    val totalPrice: Double
        get() = price * quantity
}
