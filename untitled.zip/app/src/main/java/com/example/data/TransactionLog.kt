package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transaction_logs")
data class TransactionLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val refNumber: String,          // Transaction reference number generated on payment
    val timestamp: Long = System.currentTimeMillis(),
    val totalItems: Int,
    val subtotal: Double,
    val discount: Double,
    val tax: Double,
    val grandTotal: Double,
    val paymentMethod: String,     // "Easypaisa", "JazzCash", "Bank Transfer"
    val accountMobile: String,     // Store checkout account number / phone used
    val status: String,            // "Paid", "Pending Verify"
    val storeName: String = "Al-Madina General Store"
)
