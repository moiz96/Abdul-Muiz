package com.example.data

import kotlinx.coroutines.flow.Flow

class GroceryRepository(private val groceryDao: GroceryDao) {
    
    val allProducts: Flow<List<Product>> = groceryDao.getAllProducts()
    val cartItems: Flow<List<CartItem>> = groceryDao.getCartItems()
    val allTransactions: Flow<List<TransactionLog>> = groceryDao.getAllTransactions()

    suspend fun getProductByBarcode(barcode: String): Product? {
        return groceryDao.getProductByBarcode(barcode)
    }

    suspend fun addProductToCart(product: Product) {
        val existingItem = groceryDao.getCartItem(product.barcode)
        if (existingItem != null) {
            groceryDao.updateCartItem(existingItem.copy(quantity = existingItem.quantity + 1))
        } else {
            groceryDao.insertCartItem(
                CartItem(
                    barcode = product.barcode,
                    name = product.name,
                    urduName = product.urduName,
                    price = product.price,
                    unit = product.unit,
                    quantity = 1
                )
            )
        }
    }

    // Direct add by scanner or manual entry
    suspend fun addBarcodeToCart(barcode: String): Product? {
        val product = groceryDao.getProductByBarcode(barcode)
        if (product != null) {
            addProductToCart(product)
            return product
        }
        return null
    }

    suspend fun increaseCartQuantity(barcode: String) {
        groceryDao.getCartItem(barcode)?.let { item ->
            groceryDao.updateCartItem(item.copy(quantity = item.quantity + 1))
        }
    }

    suspend fun decreaseCartQuantity(barcode: String) {
        groceryDao.getCartItem(barcode)?.let { item ->
            if (item.quantity > 1) {
                groceryDao.updateCartItem(item.copy(quantity = item.quantity - 1))
            } else {
                groceryDao.deleteCartItem(barcode)
            }
        }
    }

    suspend fun removeCartItem(barcode: String) {
        groceryDao.deleteCartItem(barcode)
    }

    suspend fun clearCart() {
        groceryDao.clearCart()
    }

    suspend fun prepopulateProductsIfNeeded() {
        if (groceryDao.getProductCount() == 0) {
            val defaultProducts = listOf(
                Product("PROD-MILK", "Olper's UHT Milk", "اولپرز دودھ", 290.0, "Dairy", "1 Litre Carton", 140),
                Product("PROD-GHEE", "Banaspati Ghee", "بناسپتی گھی", 540.0, "Grocery", "1 kg Blue Band", 45),
                Product("PROD-RICE", "Basmati Rice (Super)", "باسمتی چاول", 380.0, "Grocery", "1 kg Mughal Kernal", 80),
                Product("PROD-SUGAR", "Refined Sugar (Cheeni)", "چینی", 160.0, "Grocery", "1 kg Pack", 120),
                Product("PROD-TEA", "Tapal Danedar Tea", "ٹاپل چائے", 650.0, "Beverages", "450 grams Pack", 35),
                Product("PROD-CHILLI", "National Chilli Powder", "سرخ مرچ پاؤڈر", 240.0, "Spices", "200 grams Pack", 50),
                Product("PROD-SURF", "Surf Excel Powder", "سرف ایکسل", 350.0, "Household", "500 grams Pack", 60),
                Product("PROD-SOAP", "Lux Velvet Touch Soap", "لکس صابن", 150.0, "Personal Care", "140 grams Bar", 95),
                Product("PROD-SOOPER", "Peak Freans Sooper Biscuits", "سوپر بسکٹ", 100.0, "Snacks", "Half-Roll Family Pack", 110),
                Product("PROD-EGGS", "Farm fresh Eggs", "فارم کے انڈے", 280.0, "Dairy", "1 Dozen Box", 30)
            )
            groceryDao.insertProducts(defaultProducts)
        }
    }

    suspend fun saveTransaction(transaction: TransactionLog) {
        groceryDao.insertTransaction(transaction)
    }
}
